# OWASP Juice Shop – Upload Size Challenge Evidence (File Upload)

> Tested on a local, intentionally vulnerable training app (OWASP Juice Shop) at `http://127.0.0.1:3000`.
> Tools: Burp Suite Community, Firefox, Kali Linux.

## Summary

The evidence documents successful completion of the OWASP Juice Shop **Upload Size** challenge. The page displays the success message “Upload a file larger than 100 kB”; the terminal reports **118K** for `real-test.pdf`; and Burp shows a `POST /file-upload` request with an `application/pdf` file part and HTTP **204 No Content**.

**Scope limitation:** This is challenge-completion evidence, not proof of an unrestricted file-upload vulnerability, malicious file execution, or a server-side validation bypass.

| Field | Value |
|---|---|
| Finding | Upload Size challenge completion evidence |
| Category | Not assigned – no independent vulnerability confirmed |
| Endpoint | `POST /file-upload` |
| Authentication | Not conclusively established by supplied screenshots |
| Observed result | HTTP 204 No Content; Juice Shop success banner |
| Challenge solved | **Upload Size** – upload a file larger than 100 kB |

## Test Accounts

The supplied evidence does not provide enough reliable information to identify attacker/victim accounts or user IDs. No account identifiers are inferred.

## Steps to Reproduce

### 1. Complaint form

The Juice Shop Complaint page is shown with the invoice upload control.

![Complaint page](images/04-complaint-page.jpg)

### 2. Burp upload request

Burp captures `POST /file-upload` with multipart field `file`, filename `real-test.pdf`, and content type `application/pdf`. Only the visible session-token value is redacted; the remaining request details are preserved.

![Burp upload request with token redacted](images/02-burp-upload-request-redacted.jpg)

### 3. Burp HTTP history

The HTTP history shows `POST /file-upload` and an HTTP `204` response. The visible Authorization value is `Bearer null`; request headers and multipart details remain readable.

![Burp HTTP history](images/03-burp-http-history.jpg)

### 4. File size verification

The Kali terminal output from `ls -lh real-test.pdf` reports **118K**, above the challenge's stated 100 kB threshold.

![File size proof](images/05-file-size-proof-118k.png)

### 5. Challenge completion

The Juice Shop page displays the success notifications, including Upload Size.

![Challenge success banners](images/01-challenge-success-banners.jpg)

## Result

The screenshots support the conclusion that the Upload Size challenge was completed using a PDF reported as 118K, and that the upload request received 204 No Content.

## Root Cause

Not determined from the supplied evidence. The challenge success banner confirms the challenge condition was met, but it does not reveal the underlying application logic or prove a production security weakness.

## Impact

No independent confidentiality, integrity, or availability impact is demonstrated. Do not classify this as an exploitable unrestricted-upload issue without additional testing, including server-side type/size enforcement and whether uploaded content can be retrieved or executed.

## Remediation

- Enforce upload size limits server-side.
- Validate file type using content inspection (magic bytes), not only filename or MIME type.
- Store uploaded files outside the web root and prevent execution.
- Generate safe server-side filenames and enforce authorization checks.
- Log upload decisions and return consistent rejection responses.

## References

- OWASP Cheat Sheet Series – File Upload Cheat Sheet
- OWASP Juice Shop – intentionally vulnerable training application

## Disclaimer

For educational purposes only, performed on a local lab environment. The visible session-token value in the Burp request screenshot has been redacted.
